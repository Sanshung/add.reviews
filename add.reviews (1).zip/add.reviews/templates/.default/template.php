<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

/**
 * Bitrix vars
 *
 * @var array $arParams
 * @var array $arResult
 * @var CBitrixComponentTemplate $this
 * @global CMain $APPLICATION
 * @global CUser $USER
 */

use Bitrix\Main\Localization\Loc;

Loc::loadMessages(
    $_SERVER["DOCUMENT_ROOT"] . '/local/lang.php'
);

?>


<h2><?$APPLICATION->ShowTitle()?></h2>
<div class="review-form">

    <form id="review-send" action="<?= POST_FORM_ACTION_URI ?>" method="POST">
        <?= bitrix_sessid_post() ?>
        <input type="hidden" name="PARAMS_HASH" value="<?=$arResult["PARAMS_HASH"]?>">
        <? if (!empty($arResult["ERROR_MESSAGE"])) {
            foreach ($arResult["ERROR_MESSAGE"] as $v)
                ShowError($v);
        }
        if (strlen($arResult["OK_MESSAGE"]) > 0) {
            ?>
            <div class="mf-ok-text"><?= $arResult["OK_MESSAGE"] ?></div><?
        }
        ?>
        <? if (empty($arResult["OK_MESSAGE"])): ?>
            <div class="row">
                <div class="col-md-6 col-12">
                    <input type="text" name="user_name" placeholder="Имя" required="" value="<?= $arResult["AUTHOR_NAME"] ?>" />
                    <input type="text" class="phone-input" name="user_phone" placeholder="Мобильный телефон" required="" value="<?= $arResult["AUTHOR_PHONE"] ?>" />
                </div>
                <div class="col-md-6 col-12">
                    <textarea type="text" rows="4" name="MESSAGE" placeholder="Комментарий" required=""><?= $arResult["MESSAGE"] ?></textarea>
                </div>
                <div class="col-md-6 col-12">
                </div>
                <div class="col-md-6 col-12">
                    <div class="review-input-bottom">
                        <a href="/confidential/">Политика конфиденциальности</a>
                        <button type="submit" name="submit" value="Y" class="button big">Отправить</button>
                    </div>
                </div>
            </div>

        <? endif; ?>
    </form>
</div>