<?php
if(!defined("B_PROLOG_INCLUDED")||B_PROLOG_INCLUDED!==true)die();

/**
 * Bitrix vars
 *
 * @var array $arParams
 * @var array $arResult
 * @var CBitrixComponent $this
 * @global CMain $APPLICATION
 * @global CUser $USER
 */

use Bitrix\Main\Localization\Loc;
Loc::loadMessages(
    $_SERVER["DOCUMENT_ROOT"].'/local/lang.php'
);


$arResult["PARAMS_HASH"] = md5(serialize($arParams).$this->GetTemplateName());

if($arParams["OK_TEXT"] == '')
	$arParams["OK_TEXT"] = "Спасибо за отзыв";

if($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["submit"] <> '' && (!isset($_POST["PARAMS_HASH"]) || $arResult["PARAMS_HASH"] === $_POST["PARAMS_HASH"]))
{
	$arResult["ERROR_MESSAGE"] = array();
	if(check_bitrix_sessid())
	{
		if(empty($arParams["REQUIRED_FIELDS"]) || !in_array("NONE", $arParams["REQUIRED_FIELDS"]))
		{
			if(strlen($_POST["user_name"]) <= 1)
				$arResult["ERROR_MESSAGE"][] = Loc::getMessage("Поле имя обязательно для заполнения");
			if(strlen($_POST["user_phone"]) <= 1)
				$arResult["ERROR_MESSAGE"][] = Loc::getMessage("Поле телефон обязательно для заполнения");
			if(strlen($_POST["MESSAGE"]) <= 3)
				$arResult["ERROR_MESSAGE"][] = Loc::getMessage("Поле отзыв обязательно для заполнения");
		}
		//if(strlen($_POST["user_email"]) > 1 && !check_email($_POST["user_email"]))
		//	$arResult["ERROR_MESSAGE"][] = Loc::getMessage("MF_EMAIL_NOT_VALID");

		if(empty($arResult["ERROR_MESSAGE"]))
		{
		    \Bitrix\Main\Loader::includeModule('iblock');
            $el = new CIBlockElement;
            $PROP = array();
            $PROP['PHONE'] = $_POST["user_phone"];
			$arFields = Array(
			    "IBLOCK_ID" => 8,
                "PROPERTY_VALUES"=> $PROP,
				"NAME" => $_POST["user_name"],
				"PREVIEW_TEXT" => $_POST["MESSAGE"],
				"ACTIVE" => "N",
			);

            $_SESSION["MF_NAME"] = htmlspecialcharsbx($_POST["user_name"]);
            $_SESSION["MF_PHONE"] = htmlspecialcharsbx($_POST["user_phone"]);

            if($PRODUCT_ID = $el->Add($arFields))
                LocalRedirect($APPLICATION->GetCurPageParam("success=".$arResult["PARAMS_HASH"], Array("success")));
            else
                $arResult["ERROR_MESSAGE"][] = $el->LAST_ERROR;


			/*if(!empty($arParams["EVENT_MESSAGE_ID"]))
			{
				foreach($arParams["EVENT_MESSAGE_ID"] as $v)
					if(IntVal($v) > 0)
						CEvent::Send($arParams["EVENT_NAME"], SITE_ID, $arFields, "N", IntVal($v));
			}
			else
				CEvent::Send($arParams["EVENT_NAME"], SITE_ID, $arFields);*/


		}
		
		$arResult["MESSAGE"] = htmlspecialcharsbx($_POST["MESSAGE"]);
		$arResult["AUTHOR_NAME"] = htmlspecialcharsbx($_POST["user_name"]);
		$arResult["AUTHOR_PHONE"] = htmlspecialcharsbx($_POST["user_phone"]);
	}
	else
		$arResult["ERROR_MESSAGE"][] = GetMessage("MF_SESS_EXP");
}
elseif($_REQUEST["success"] == $arResult["PARAMS_HASH"])
{
	$arResult["OK_MESSAGE"] = $arParams["OK_TEXT"];
}

if(empty($arResult["ERROR_MESSAGE"]))
{
	if($USER->IsAuthorized())
	{
		$arResult["AUTHOR_NAME"] = $USER->GetFormattedName(false);
		//$arResult["AUTHOR_EMAIL"] = htmlspecialcharsbx($USER->GetEmail());
	}
	else
	{
		if(strlen($_SESSION["MF_NAME"]) > 0)
			$arResult["AUTHOR_NAME"] = htmlspecialcharsbx($_SESSION["MF_NAME"]);
		if(strlen($_SESSION["MF_PHONE"]) > 0)
			$arResult["AUTHOR_PHONE"] = htmlspecialcharsbx($_SESSION["MF_PHONE"]);
	}
}


$this->IncludeComponentTemplate();
