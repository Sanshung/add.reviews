<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();


$arComponentParameters = array(
	"PARAMETERS" => array(
		"AJAX_MODE" => Array(
			"NAME" => "Включить режим AJAX",
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "Y",
			"PARENT" => "BASE",
		),
        "AJAX_OPTION_JUMP" => Array(
			"NAME" => "AJAX_OPTION_JUMP",
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "N",
			"PARENT" => "BASE",
		),
        "AJAX_OPTION_HISTORY" => Array(
			"NAME" => "AJAX_OPTION_HISTORY",
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "N",
			"PARENT" => "BASE",
		),


	)
);


?>